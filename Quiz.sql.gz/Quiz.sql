-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 04, 2021 at 04:23 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Quiz`
--

-- --------------------------------------------------------

--
-- Table structure for table `Category`
--

CREATE TABLE `Category` (
  `id` int(11) NOT NULL,
  `topic` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Category`
--

INSERT INTO `Category` (`id`, `topic`) VALUES
(1, 'PHP'),
(2, 'PYTHON'),
(3, 'Java'),
(4, 'Database'),
(5, 'test');

-- --------------------------------------------------------

--
-- Table structure for table `Questions`
--

CREATE TABLE `Questions` (
  `id` int(11) NOT NULL,
  `topic` varchar(255) NOT NULL,
  `question` varchar(255) NOT NULL,
  `optOne` varchar(255) NOT NULL,
  `optTwo` varchar(255) NOT NULL,
  `optThree` varchar(255) NOT NULL,
  `optFour` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Questions`
--

INSERT INTO `Questions` (`id`, `topic`, `question`, `optOne`, `optTwo`, `optThree`, `optFour`, `answer`) VALUES
(1, 'PHP', 'Which of the following is used to declare a constant', 'const', 'constant', 'constt', '#pragma', '2'),
(2, 'PHP', 'Which of the following is used to declare a constant', 'const', 'constant', 'define', '#pragma', '1'),
(3, 'PHP', 'What gets printed?', 'true', 'false', 'both', 'none', '1'),
(4, 'PHP', 'Which of the following is the way to create comments in PHP?', '// commented code to end of line', '/* commented code here */', '# commented code to end of line', 'all of the above', '3'),
(5, 'PHP', 'What does PHP stand for?', 'Preprocessed Hypertext Page', 'Hypertext Markup Language', 'PHP: Hypertext Preprocessor', 'Hypertext Transfer Protocol', '4'),
(6, 'PHP', ' Which of the following is NOT a valid PHP comparison operator?', ' !=', ' >=', '<=>', '<>', '3'),
(7, 'PHP', 'Which of the following is NOT a magic predefined constant?', ' __LINE__', '__FILE__', ' __DATE__ ', '__CLASS__', '2'),
(8, 'PHP', ' What is the default execution time set in set_time_limit()?', '20 secs', '30 secs', '40 secs', '35 secs', '1'),
(9, 'PHP', 'In PHP Language variables are case sensitive', 'True', 'false', 'Depends on website', 'Depends on server', '1'),
(10, 'Database', 'RDBMS is an acronym for', 'Relational Database', 'Relational Database Merging System', 'Relational Database Management System', 'Relational Database Manipulation System', '4'),
(11, 'Database', 'The process of performing corrections on the existing data is', 'Merging', 'Sorting', 'Filtering', 'Editing', '4'),
(12, 'Database', 'Database management systems ___ data.', 'Delete', 'Share', 'Process', 'Store', '2'),
(13, 'Database', 'Hierarchical database was primarily used on', 'Business Computers', 'Mainframe Computers', 'Personal Computers', 'Super Computers', '2'),
(14, 'Database', 'DBMS is an acronym for', 'Database Merging System', 'Database', 'Database Management System', 'Database Manipulating System', '3'),
(15, 'Database', 'A report is printed information based on', 'Database Merging System', 'Form', 'Input', 'Query', '4'),
(16, 'Database', 'The set of processed data is called', 'Database', 'Database', 'Datum', 'Data', '2'),
(17, 'Database', 'A query is also a type of', 'Filter', 'Database', 'Form', 'Report', '1'),
(18, 'Database', 'In how many ways manipulation of data can be performed?', '5', '7', '8', '10', '2'),
(19, 'Database', 'The term data is derived from the word,', 'Value', 'Entities', 'Datum', 'Fact', '3'),
(20, 'PYTHON', ' How will you not create a dictionary?', '256', '32768', '65536', 'This code raises an exception', '3'),
(21, 'PYTHON', 'What is the value of round(12.5) - round(11.5)?', '0', '1', '2', 'This code will raise an exception', '1'),
(22, 'PYTHON', 'What is the size of an empty tuple in Python?', '0', '8', '32', '48', '1'),
(23, 'Java', 'Which of the following is not a keyword in java?', 'static', 'Boolean', 'void', 'private', '2'),
(24, 'Java', 'What is the size of boolean variable?', '8 bit', '16 bit', '32 bit', 'not precisely defined', '2'),
(25, 'Java', 'What is the default value of int variable?', '0', '0.0', 'NULL', 'not define', '1'),
(26, 'Java', 'What kind of variables a class can consist of?', 'class variables, instance variables', 'class variables, local variables, instance variables', 'class variables', 'class variables, local variables', '2'),
(27, 'test', 'Are you sure you want to quit ?', 'Yes', 'No', '', '', '1');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `isadmin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `name`, `email`, `password`, `date`, `isadmin`) VALUES
(1, 'Sher Khan', 'singhsumit880@gmail.com', '111', '2021-02-01', 0),
(2, 'Ashutosh', 'ashutosh@gmail.com', '111', '2021-02-01', 0),
(3, 'Sunil', 'sunil@gmail.com', '111', '2021-02-01', 0),
(4, 'Sher Khan', 'sher@gmail.com', '111', '2021-02-01', 1),
(5, 'Sher Khan', 'sher@gmail.com', '123', '2021-02-01', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Category`
--
ALTER TABLE `Category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Questions`
--
ALTER TABLE `Questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Category`
--
ALTER TABLE `Category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `Questions`
--
ALTER TABLE `Questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
